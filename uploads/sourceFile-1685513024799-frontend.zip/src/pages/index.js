import { Open_Sans } from '@next/font/google'
const openSansFont = Open_Sans({ subsets: ['latin'] })

export default function Home() {
  return (
    <>
      <h1 className={openSansFont.className}>
        Welcome Template Studio
      </h1>
    </>
  )
}
