import { TextField,Button } from "@mui/material";
import Link from "next/link";
import { useRouter } from "next/router";
import { useState } from "react";
import Layout from "../layout";

export default function Login() {
  const router = useRouter();

  const [formData,setFormData] = useState({
    email: '',
    password: ''
  });

  const updateFormData = (e)=>{
    setFormData(prevalue=>{
      return {
        ...prevalue,
        [e.target.name] : e.target.value
      }
    });
  }

  let handleSubmit = (e)=>{
    e.preventDefault();
    fetch("http://localhost:7777/auth/login",{
      method : "POST",  
      headers: {
        'Content-Type': 'application/json'
      },
      body : JSON.stringify(formData)
    })
    .then(response=>response.json())
    .then(async result=>{
      console.log(result);
      if(result.success){
        localStorage.setItem("token",result.token)
        router.push("/dashboard");
      }else{
        if(result.message){
          alert(result.message);
        }else{
          alert(`There is some Error Please Try Again later`)    
        }
      }
    })
    .catch(err=>{
      console.log(err)
      alert(`There is some Error Please Try Again later`)
    })
  }




  return (
    <>
      <form style={{maxWidth: "500px",width: "100%"}} onSubmit={handleSubmit}>
        <h1 style={{ marginBottom : '20px'}}>
          Login
        </h1>
          <TextField fullWidth  label="Email" variant="outlined" type="email" value={formData.email} name="email" onInput={updateFormData}/>
          <TextField fullWidth  label="Password" variant="outlined" type="text" sx={{ my : 2}} value={formData.password} name="password" onInput={updateFormData}/>
          <Link variant="contained" href="forget-password">
            Forget Password
          </Link>
          <Button variant="contained" type="submit">Login</Button>
      </form>
    </>
  )
}

Login.getLayout = function  getLayout(page){
    return (<Layout variant="Auth">{page}</Layout>)
};