﻿using Syncfusion.XlsIO;
using System.Reflection;
using System.IO;

namespace ChartSample
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ExcelEngine excelEngine = new ExcelEngine())
            {
                IApplication application = excelEngine.Excel;
                application.DefaultVersion = ExcelVersion.Excel2016;

                //Open existing workbook with data entered
                Assembly assembly = typeof(Program).GetTypeInfo().Assembly;
                Stream fileStream = assembly.GetManifestResourceStream("ChartSample.InputTemplate.xlsx");
                IWorkbook workbook = application.Workbooks.Open(fileStream);
                IWorksheet worksheet = workbook.Worksheets[0];

                //Initialize chart and assign data
                IChartShape chart = worksheet.Charts.Add();
                chart.DataRange = worksheet["A1:F6"];
                chart.ChartType = ExcelChartType.Stock_VolumeOpenHighLowClose;

                //Apply chart elements
                //Set Chart Title
                chart.ChartTitle = "Volume-Open-High-Low-Close Chart";

                //Set Legend
                chart.HasLegend = true;
                chart.Legend.Position = ExcelLegendPosition.Bottom;

                //Set Datalabels
                IChartSerie serie1 = chart.Series[1];
                IChartSerie serie2 = chart.Series[2];
                IChartSerie serie3 = chart.Series[3];
                IChartSerie serie4 = chart.Series[4];

                serie1.DataPoints.DefaultDataPoint.DataLabels.IsValue = true;
                serie1.DataPoints.DefaultDataPoint.DataLabels.IsSeriesName = true;
                serie1.SerieFormat.MarkerStyle = ExcelChartMarkerType.Circle;
                serie1.SerieFormat.MarkerBackgroundColorIndex = ExcelKnownColors.Lavender;

                serie2.DataPoints.DefaultDataPoint.DataLabels.IsValue = true;
                serie2.DataPoints.DefaultDataPoint.DataLabels.IsSeriesName = true;
                serie2.SerieFormat.MarkerStyle = ExcelChartMarkerType.Circle;
                serie2.SerieFormat.MarkerBackgroundColorIndex = ExcelKnownColors.LightGreen;

                serie3.DataPoints.DefaultDataPoint.DataLabels.IsValue = true;
                serie3.DataPoints.DefaultDataPoint.DataLabels.IsSeriesName = true;
                serie3.SerieFormat.MarkerStyle = ExcelChartMarkerType.Circle;
                serie3.SerieFormat.MarkerBackgroundColorIndex = ExcelKnownColors.Red;

                serie4.DataPoints.DefaultDataPoint.DataLabels.IsValue = true;
                serie4.DataPoints.DefaultDataPoint.DataLabels.IsSeriesName = true;
                serie4.SerieFormat.MarkerStyle = ExcelChartMarkerType.Circle;
                serie4.SerieFormat.MarkerBackgroundColorIndex = ExcelKnownColors.Light_yellow;

                //Positioning the chart in the worksheet
                chart.TopRow = 8;
                chart.LeftColumn = 1;
                chart.BottomRow = 23;
                chart.RightColumn = 8;

                //Saving the workbook
                Stream stream = File.Create("Output.xlsx");
                workbook.SaveAs(stream);
            }
        }
    }
}
